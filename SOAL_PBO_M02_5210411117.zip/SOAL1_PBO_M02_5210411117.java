/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package nendyna;

import java.util.Scanner;

/**
 *
 * @author USER
 */
public class SOAL1_PBO_M02_5210411117 {
    public static void main(String[] args) {
        String nama, alamat, bulan;
        int tanggal ;
        int tahun ;
        int usia ;
        
        nama = "NENDY NAILUL AUTOR";
        alamat = "Selokan Mataram, Sleman, Yogyakarta";
        tanggal = 03;
        bulan = "maret";
        tahun = 2003;
        usia = 2022-2003;
        
        System.out.println("Hai nama saya " + nama);
        System.out.println("Sekarang saya tinggal di " + alamat);
        System.out.println("Saya lahir pada tanggal " + tanggal + "bulan" + bulan + "tahun" + tahun);
        System.out.println("Sehingga pada tahun 2022 ini saya akan berusia " + usia);
    }
}
