/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbo_mo5_5210411117;
import java.util.Scanner;
/**
 *
 * @author NENDY NAILUL AUTOR
 */
public class Mobil {
    private String pabrikan;
    private String model;
    private String jenis;
    private Integer kapasitasPenumpang;
    private String warna;
    private Integer kapasitasSilinder;
    private Integer panjangWheelbase;
    private double hargaCash;
    private double downPayment;
    private Integer tenure;
    private double installment;

    public Mobil() { 
    }

    public Mobil(String pabrikan, String model, String jenis, Integer 
        kapasitasPenumpang, String warna, Integer kapasitasSilinder, Integer panjangWheelbase,
        Double hargaCash, Double downPayment, Integer tenure, Double installment){
        this.pabrikan = pabrikan;
        this.model = model;
        this.jenis = jenis;
        this.kapasitasPenumpang = kapasitasPenumpang;
        this.warna = warna;
        this.kapasitasSilinder = kapasitasSilinder;
        this.panjangWheelbase = panjangWheelbase;
        this.hargaCash = hargaCash;
        this.downPayment = downPayment;
        this.tenure = tenure;
        this.installment = installment;
    }

    public void setPabrikan(String pabrikan) {
        this.pabrikan = pabrikan;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setJenis(String jenis) {
        this.jenis = jenis;
    }

    public void setKapasitasPenumpang(Integer kapasitasPenumpang) {
        this.kapasitasPenumpang = kapasitasPenumpang;
    }

    public void setWarna(String warna) {
        this.warna = warna;
    }

    public void setKapasitasSilinder(Integer kapasitasSilinder) {
        this.kapasitasSilinder = kapasitasSilinder;
    }

    public void setPanjangWheelbase(Integer panjangWheelbase) {
        this.panjangWheelbase = panjangWheelbase;
    }

    public void setHargaCash(double hargaCash) {
        this.hargaCash = hargaCash;
    }

    public void setDownPayment(double downPayment) {
        this.downPayment = downPayment;
    }

    public void setTenure(Integer tenure) {
        this.tenure = tenure;
    }

    public void setInstallment(double installment) {
        this.installment = installment;
    }

    public String getPabrikan() {
        return pabrikan;
    }

    public String getModel() {
        return model;
    }

    public String getJenis() {
        return jenis;
    }

    public Integer getKapasitasPenumpang() {
        return kapasitasPenumpang;
    }

    public String getWarna() {
        return warna;
    }

    public Integer getKapasitasSilinder() {
        return kapasitasSilinder;
    }

    public Integer getPanjangWheelbase() {
        return panjangWheelbase;
    }

    public double getHargaCash() {
        return hargaCash;
    }

    public double getDownPayment() {
        return downPayment;
    }

    public Integer getTenure() {
        return tenure;
    }

    public double getInstallment(){
        return installment;
    }
    
    public double hitungHargaKredit(double downPayment, int tenure, double installment){
        double harga_kredit;
        harga_kredit = downPayment;
        for (int i = 0; i < tenure; i++) {
            harga_kredit += installment;
        }
return harga_kredit;
    }
    public void tampilHargaKredit(){
        System.out.println("Harga Kredit \t\t: Rp." 
        + hitungHargaKredit(getDownPayment(), getTenure(), getInstallment()));
    }
    public void tampilInfoMobil() {
        System.out.println("Pabrikan \t\t: " +getPabrikan());
        System.out.println("Model \t\t\t: " +getModel());
        System.out.println("Jenis \t\t\t: " +getJenis());
        System.out.println("KapasitasPenumpang \t: " +getKapasitasPenumpang());
        System.out.println("Warna \t\t\t: " +getWarna());
        System.out.println("Kapasitas Silinder \t: " +getKapasitasSilinder());
        System.out.println("Panjang Wheelbase \t: " +getPanjangWheelbase() +" mm");
        System.out.println("Harga Cash \t\t: Rp." +getHargaCash() +" juta");
        System.out.println("Down Payment \t\t: Rp." +getDownPayment() +" juta");
        System.out.println("Tenure \t\t\t: " +getTenure());
        System.out.println("Installment \t\t: Rp." +getInstallment() +" juta");
        tampilHargaKredit();
    }
}
