/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pbo_mo5_5210411117;
import java.util.Scanner;
/**
 *
 * @author NENDY NAILUL AUTOR
 */
public class Main_PBO_MO5_5210411117 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         Scanner sc = new Scanner(System.in);
        boolean lanjut;
        lanjut = true;
        
        Mobil mobil;     
        mobil = new Mobil();
        while (lanjut) {    
            System.out.println("Pilihan Menu :");
            System.out.println("1. Buat Objek Mobil");
            System.out.println("2. Tampil Info Objek Mobil");
            System.out.println("3. Keluar Program");
        
            System.out.println("\npilih menu : ");
            int menu = sc.nextInt();
            sc.nextLine();
            
            switch (menu) {
                case 1 -> {
                    System.out.println("objek mobil");
                    
                    System.out.print("Pabrikan \t\t: ");
                    String pabrikan = sc.nextLine();
                    
                    System.out.print("Model \t\t\t: ");
                    String model = sc.nextLine();
                    
                    System.out.print("Jenis \t\t\t: ");
                    String jenis = sc.nextLine();

                    System.out.print("Kapasitas Penumpang \t: ");
                    int kapasitasPenumpang = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Warna \t\t\t: ");
                    String warna = sc.nextLine();

                    System.out.print("Kapasitas Silinder \t: ");
                    int kapasitasSilinder = sc.nextInt();

                    System.out.print("Panjang Wheelbase \t: ");
                    int panjangWheelbase = sc.nextInt();

                    System.out.print("Harga Cash \t\t: ");
                    double hargaCash = sc.nextDouble();

                    System.out.print("Down Payment \t\t: ");
                    double downPayment = sc.nextDouble();

                    System.out.print("Tenure \t\t\t: ");
                    int tenure = sc.nextInt();

                    System.out.print("Installment \t\t\t: ");
                    double installment = sc.nextDouble();
                    
                    mobil = new Mobil(pabrikan, model, jenis, kapasitasPenumpang, warna, 
                            kapasitasSilinder, panjangWheelbase, hargaCash, downPayment, tenure, installment);
                 }
                case 2 -> mobil.tampilInfoMobil();
                case 3 -> lanjut = false;
            }
        }
    }
}